from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    bot_token: str
    webapp_url: str = "http://127.0.0.1:8000/app/"
    database_url: str = "sqlite+aiosqlite:///./gazfree.db"
    admin_secret: str = "change-me"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
engine = create_async_engine(settings.database_url, echo=False)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

async def get_session() -> AsyncSession:
    async with SessionLocal() as session:
        yield session

async def init_db():
    from database.models import User, InventoryItem, Operation, PromoRedemption
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
