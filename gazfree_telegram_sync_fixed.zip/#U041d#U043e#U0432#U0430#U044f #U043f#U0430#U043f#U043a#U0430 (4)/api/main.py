from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from database.database import init_db
from api.routes import profile, inventory, games, withdrawals

@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield

app = FastAPI(title='GazFree API', lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=False,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.mount("/app", StaticFiles(directory="webapp", html=True), name="webapp")
app.include_router(profile.router, prefix="/api")
app.include_router(inventory.router, prefix="/api")
app.include_router(games.router, prefix="/api")
app.include_router(withdrawals.router, prefix="/api")

@app.get("/")
async def root():
    return {"ok": True, "app": "GazFree", "webapp": "/app/", "telegram_auth": True}

@app.get("/health")
async def health():
    return {"ok": True}
