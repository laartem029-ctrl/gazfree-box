import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete

from database.database import get_session, settings
from database.models import User, InventoryItem, PromoRedemption

router = APIRouter(tags=["profile"])

def _parse_init_data(init_data: str) -> dict:
    if not init_data:
        raise HTTPException(401, "Telegram Mini App initData is required")
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = data.pop("hash", None)
        if not received_hash:
            raise ValueError("missing hash")
        secret = hmac.new(b"WebAppData", settings.bot_token.encode(), hashlib.sha256).digest()
        check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
        calculated = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            raise ValueError("invalid hash")
        auth_date = int(data.get("auth_date", "0"))
        if not auth_date or abs(time.time() - auth_date) > 86400:
            raise ValueError("expired initData")
        user = json.loads(data["user"])
        if not user.get("id"):
            raise ValueError("missing user")
        return user
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(401, "Invalid Telegram Mini App data") from exc

async def get_tg_user(x_telegram_init_data: str | None):
    return _parse_init_data(x_telegram_init_data or "")

async def current_user(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = await get_tg_user(x_telegram_init_data)
    user_id = int(tg_user["id"])
    user = await session.get(User, user_id)
    if not user:
        user = User(id=user_id, username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", balance=0)
        session.add(user)
        await session.commit()
        await session.refresh(user)
    else:
        user.username = tg_user.get("username")
        user.first_name = tg_user.get("first_name") or user.first_name
        await session.commit()
    return user

@router.post("/profile/sync")
async def sync_profile(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = await get_tg_user(x_telegram_init_data)
    user = await session.get(User, int(tg_user["id"]))
    created = user is None
    if created:
        user = User(id=int(tg_user["id"]), username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", balance=0)
        session.add(user)
    else:
        user.username = tg_user.get("username")
        user.first_name = tg_user.get("first_name") or user.first_name
    await session.commit()
    return {"ok": True, "created": created, "id": user.id, "balance": user.balance, "username": user.username, "first_name": user.first_name}

@router.get("/profile")
async def profile(user: User = Depends(current_user)):
    return {
        "id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "balance": user.balance,
        "stats": {"opened_cases": user.opened_cases, "wins": user.wins, "upgrades": user.upgrades},
    }

@router.get("/profile/state")
async def profile_state(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = await get_tg_user(x_telegram_init_data)
    user = await session.get(User, int(tg_user["id"]))
    if not user:
        user = User(id=int(tg_user["id"]), username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", balance=0)
        session.add(user)
        await session.commit()
        await session.refresh(user)
    result = await session.execute(select(InventoryItem).where(InventoryItem.user_id == user.id, InventoryItem.status == "active").order_by(InventoryItem.id.asc()))
    inventory = [{"id": x.id, "name": x.item_name, "price": x.item_price, "image": x.image} for x in result.scalars()]
    return {
        "id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "balance": user.balance,
        "stats": {"opened_cases": user.opened_cases, "wins": user.wins, "upgrades": user.upgrades},
        "inventory": inventory,
    }

@router.post("/profile/state")
async def save_profile_state(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = await get_tg_user(x_telegram_init_data)
    user_id = int(tg_user["id"])
    user = await session.get(User, user_id)
    if not user:
        user = User(id=user_id, username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", balance=0)
        session.add(user)
    user.username = tg_user.get("username")
    user.first_name = tg_user.get("first_name") or user.first_name
    user.balance = max(0, int(payload.get("balance") or 0))
    stats = payload.get("stats") or {}
    user.opened_cases = max(0, int(stats.get("opened_cases") or 0))
    user.wins = max(0, int(stats.get("wins") or 0))
    user.upgrades = max(0, int(stats.get("upgrades") or 0))

    inventory = payload.get("inventory") or []
    if not isinstance(inventory, list):
        inventory = []
    await session.execute(delete(InventoryItem).where(InventoryItem.user_id == user_id))
    for item in inventory:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "Подарок")[:255]
        price = max(0, int(item.get("price") or 0))
        image = item.get("icon") or item.get("image")
        session.add(InventoryItem(user_id=user_id, item_name=name, item_price=price, image=str(image)[:500] if image is not None else None, status="active"))
    await session.commit()
    return {"ok": True, "id": user_id, "balance": user.balance}

@router.post("/profile/balance")
async def sync_balance(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = await get_tg_user(x_telegram_init_data)
    user = await session.get(User, int(tg_user["id"]))
    if not user:
        raise HTTPException(404, "User not found")
    user.username = tg_user.get("username")
    user.first_name = tg_user.get("first_name") or user.first_name
    user.balance = max(0, int(payload.get("balance") or 0))
    await session.commit()
    return {"ok": True, "balance": user.balance}

PROMO_REWARDS = {"LAIRJKS-123-512": 6000}

@router.post("/profile/promo")
async def redeem_promo(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = await get_tg_user(x_telegram_init_data)
    user_id = int(tg_user["id"])
    raw_code = str(payload.get("code") or "").strip().upper()
    if raw_code not in PROMO_REWARDS:
        raise HTTPException(400, "Неверный промокод")
    existing = await session.scalar(select(PromoRedemption).where(PromoRedemption.user_id == user_id, PromoRedemption.code == raw_code))
    if existing:
        raise HTTPException(400, "Этот промокод уже использован")
    user = await session.get(User, user_id)
    if not user:
        user = User(id=user_id, username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", balance=0)
        session.add(user)
    amount = PROMO_REWARDS[raw_code]
    user.username = tg_user.get("username")
    user.first_name = tg_user.get("first_name") or user.first_name
    user.balance = max(0, int(user.balance or 0)) + amount
    session.add(PromoRedemption(user_id=user_id, code=raw_code, amount=amount))
    await session.commit()
    return {"ok": True, "balance": user.balance, "amount": amount}
