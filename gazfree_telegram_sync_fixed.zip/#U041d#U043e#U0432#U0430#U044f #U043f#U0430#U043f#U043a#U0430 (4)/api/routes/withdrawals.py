import html
import logging
from datetime import datetime
from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from aiogram import Bot
from aiogram.enums import ParseMode
from database.database import get_session, settings
from database.models import User
from api.routes.profile import _parse_init_data

router = APIRouter(tags=["withdrawals"])
ADMIN_USERNAME = "Ashleygi74"

logger = logging.getLogger("gazfree.withdrawals")


def _esc(value) -> str:
    """HTML-escape any user-supplied text before it goes into a Telegram message."""
    return html.escape(str(value), quote=False)


@router.post("/withdrawals")
async def create_withdrawal(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    telegram_user_id = int(tg_user["id"])
    user = await session.get(User, telegram_user_id)
    if not user:
        user = User(id=telegram_user_id, username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", balance=0)
        session.add(user)
        await session.commit()

    username = (user.username or payload.get("username") or "").lstrip("@").strip()
    first_name = user.first_name or str(payload.get("first_name") or "Игрок")
    gift_name = str(payload.get("gift_name") or "Подарок")[:255]
    gift_price = int(payload.get("gift_price") or 0)
    gift_case = str(payload.get("case") or "—")[:255]

    # Username lookup is case-insensitive: Telegram usernames aren't case-sensitive,
    # so comparing with func.lower() avoids missing the admin if the stored case differs.
    admin = (
        await session.execute(
            select(User).where(func.lower(User.username) == ADMIN_USERNAME.lower())
        )
    ).scalars().first()

    notified = False
    if admin:
        who = f"@{_esc(username)}" if username else _esc(first_name)
        text = (
            "📤 <b>НОВЫЙ ВЫВОД</b>\n\n"
            f"👤 Пользователь: {who}\n"
            f"🆔 ID: <code>{user.id}</code>\n"
            f"🎁 Что выводит: {_esc(gift_name)}\n"
            f"💎 Сумма вывода: <b>{gift_price} ⭐</b>\n"
            f"📦 Кейс: {_esc(gift_case)}\n"
            f"🕒 Время: {datetime.utcnow().strftime('%d.%m.%Y %H:%M UTC')}"
        )
        bot = Bot(settings.bot_token)
        try:
            await bot.send_message(admin.id, text, parse_mode=ParseMode.HTML)
            notified = True
        except Exception:
            # The withdrawal is still recorded client-side; notification can be retried later.
            logger.exception("Failed to notify admin (id=%s) about withdrawal from user %s", admin.id, user.id)
        finally:
            await bot.session.close()
    else:
        logger.warning(
            "Withdrawal from user %s could not be announced: no user with username '%s' in DB "
            "(the owner must send /start to the bot at least once).",
            user.id, ADMIN_USERNAME,
        )

    return {"ok": True, "notified": notified}

@router.post("/admin/give-stars")
async def admin_give_stars(
    payload: dict,
    x_admin_secret: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    if x_admin_secret != getattr(settings, "admin_secret", ""):
        raise HTTPException(403, "Forbidden")
    username = str(payload.get("username") or "").lstrip("@").strip()
    amount = int(payload.get("amount") or 0)
    if not username or amount < 25 or amount > 6000 or amount % 25:
        raise HTTPException(400, "Invalid username or amount")
    user = (await session.execute(select(User).where(User.username == username))).scalars().first()
    if not user:
        raise HTTPException(404, "User not found. The user must open the Mini App or start the bot first.")
    user.balance += amount
    await session.commit()
    return {"ok": True, "username": user.username, "balance": user.balance}
