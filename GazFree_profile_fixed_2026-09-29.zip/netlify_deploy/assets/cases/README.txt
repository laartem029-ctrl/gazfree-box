Case artwork used by the Mini App.
Files: bomzh.png, flowers.png, dogs.png, diamonds.png
