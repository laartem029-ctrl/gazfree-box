@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  echo .env не найден. Запусти SETUP_ENV.bat.
  pause
  exit /b 1
)

set "PYTHON=%LocalAppData%\Programs\Python\Python314\python.exe"
if not exist "%PYTHON%" set "PYTHON=python"

"%PYTHON%" -m uvicorn api.main:app --host 0.0.0.0 --port 8000
if errorlevel 1 (
  echo.
  echo [ERROR] API остановился. Проверь зависимости.
  pause
)
