from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import inspect, text
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    bot_token: str
    webapp_url: str = "http://127.0.0.1:8000/app/"
    database_url: str = "sqlite+aiosqlite:///./gazfree.db"
    admin_secret: str = "change-me"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
engine = create_async_engine(settings.database_url, echo=False)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

async def get_session() -> AsyncSession:
    async with SessionLocal() as session:
        yield session

async def init_db():
    from database.models import User, InventoryItem, Operation, PromoRedemption, Withdrawal
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

        # create_all() does not alter existing tables. Add new profile fields
        # safely for both the existing SQLite DB and deployed PostgreSQL DB.
        def migrate(sync_conn):
            columns = {c["name"] for c in inspect(sync_conn).get_columns("users")}
            if "photo_url" not in columns:
                sync_conn.execute(text("ALTER TABLE users ADD COLUMN photo_url VARCHAR(1000)"))
        await conn.run_sync(migrate)
