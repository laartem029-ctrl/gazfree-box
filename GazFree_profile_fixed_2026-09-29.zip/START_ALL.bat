@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

if not exist ".env" (
  echo .env не найден. Сейчас запустится настройка.
  call "%~dp0SETUP_ENV.bat"
  if not exist ".env" exit /b 1
)

start "GazFree API" cmd /k call "%~dp0START_API.bat"
timeout /t 2 /nobreak >nul
start "GazFree Bot" cmd /k call "%~dp0START_BOT.bat"

echo.
echo GazFree запущен: API + Bot.
echo.
