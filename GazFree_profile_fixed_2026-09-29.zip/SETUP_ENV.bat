@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================
echo        GazFree - настройка .env
 echo ============================================
echo.

if exist ".env" (
  echo Файл .env уже существует.
  set /p REPLACE=Пересоздать его? (Y/N): 
  if /I not "!REPLACE!"=="Y" exit /b 0
)

echo.
set /p "BOT_TOKEN=Вставь BOT_TOKEN бота: "
if "!BOT_TOKEN!"=="" (
  echo [ERROR] BOT_TOKEN не указан.
  pause
  exit /b 1
)

echo.
set /p "WEBAPP_URL=Вставь URL Netlify (например https://gazfree.netlify.app): "
if "!WEBAPP_URL!"=="" (
  echo [ERROR] WEBAPP_URL не указан.
  pause
  exit /b 1
)

set "WEBAPP_URL=!WEBAPP_URL:/=!"
if /I "!WEBAPP_URL:~-4!"=="/app" set "WEBAPP_URL=!WEBAPP_URL:~0,-4!"

>".env" echo BOT_TOKEN=!BOT_TOKEN!
>>".env" echo WEBAPP_URL=!WEBAPP_URL!
>>".env" echo DATABASE_URL=sqlite+aiosqlite:///./gazfree.db
>>".env" echo ADMIN_SECRET=change-me

echo.
echo [OK] .env создан.
echo URL: !WEBAPP_URL!
echo.
pause
