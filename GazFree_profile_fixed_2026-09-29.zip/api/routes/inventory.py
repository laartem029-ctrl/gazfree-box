from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from database.database import get_session
from database.models import InventoryItem
from api.routes.profile import _parse_init_data

router = APIRouter(tags=["inventory"])

@router.get("/inventory")
async def inventory(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    user_id = int(tg_user["id"])
    result = await session.execute(
        select(InventoryItem)
        .where(InventoryItem.user_id == user_id, InventoryItem.status == "active")
        .order_by(InventoryItem.id.desc())
    )
    return [{
        "id": x.id, "name": x.item_name, "price": x.item_price,
        "image": x.image
    } for x in result.scalars()]
