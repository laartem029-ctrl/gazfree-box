from fastapi import APIRouter

router = APIRouter(tags=["games"])

@router.get("/games")
async def games():
    return {
        "games": [
            {"id": "cases", "title": "Кейсы", "icon": "📦"},
            {"id": "upgrade", "title": "Апгрейд", "icon": "⚡"},
            {"id": "battle", "title": "Кейс Батл", "icon": "⚔️"},
            {"id": "crash", "title": "Crash", "icon": "🚀"},
        ],
        "mode": "demo",
        "note": "Игровые операции используют виртуальные очки в тестовой версии."
    }
