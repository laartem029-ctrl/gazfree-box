import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from aiogram.utils.web_app import safe_parse_webapp_init_data
from fastapi import APIRouter, Depends, Header, HTTPException
from fastapi.responses import Response
import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from database.database import get_session, settings
from database.models import User, PromoRedemption

router = APIRouter(tags=["profile"])

def _parse_init_data(init_data: str) -> dict:
    if not init_data:
        raise HTTPException(401, "Telegram Mini App initData is required")
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = data.pop("hash", None)
        if not received_hash:
            raise ValueError("missing hash")
        # Telegram Web Apps validation: secret key = HMAC_SHA256(WebAppData, bot token).
        secret = hmac.new(b"WebAppData", settings.bot_token.strip().encode(), hashlib.sha256).digest()
        check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
        calculated = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            raise ValueError("invalid hash")
        auth_date = int(data.get("auth_date", "0"))
        if not auth_date or time.time() - auth_date > 86400:
            raise ValueError("expired initData")
        user = json.loads(data["user"])
        if not user.get("id"):
            raise ValueError("missing user")
        return user
    except Exception as exc:
        raise HTTPException(401, "Invalid Telegram Mini App data") from exc

async def current_user(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    user_id = int(tg_user["id"])
    user = await session.get(User, user_id)
    if not user:
        user = User(
            id=user_id,
            username=tg_user.get("username"),
            first_name=tg_user.get("first_name") or "Игрок",
            photo_url=tg_user.get("photo_url"),
            balance=0,
        )
        session.add(user)
        await session.commit()
        await session.refresh(user)
    else:
        user.username = tg_user.get("username")
        user.first_name = tg_user.get("first_name") or user.first_name
        user.photo_url = tg_user.get("photo_url") or user.photo_url
        await session.commit()
    return user

@router.post("/profile/sync")
async def sync_profile(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    user = await session.get(User, int(tg_user["id"]))
    if not user:
        user = User(id=int(tg_user["id"]), username=tg_user.get("username"), first_name=tg_user.get("first_name") or "Игрок", photo_url=tg_user.get("photo_url"), balance=0)
        session.add(user)
    else:
        user.username = tg_user.get("username")
        user.first_name = tg_user.get("first_name") or user.first_name
        user.photo_url = tg_user.get("photo_url") or user.photo_url
    await session.commit()
    return {
        "ok": True,
        "id": user.id,
        "balance": user.balance,
        "username": user.username,
        "first_name": user.first_name,
        "avatar_url": f"/profile/avatar?v={user.id}",
        "photo_url": user.photo_url,
        "stats": {"opened_cases": user.opened_cases, "wins": user.wins, "upgrades": user.upgrades},
    }

@router.post("/profile/balance")
async def sync_balance(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    user = await session.get(User, int(tg_user["id"]))
    if not user:
        raise HTTPException(404, "User not found")
    user.username = tg_user.get("username")
    user.first_name = tg_user.get("first_name") or user.first_name
    user.photo_url = tg_user.get("photo_url") or user.photo_url
    new_balance = max(0, int(payload.get("balance") or 0))
    base_balance = payload.get("base_balance")
    if base_balance is not None and int(base_balance) != int(user.balance or 0):
        await session.rollback()
        raise HTTPException(409, "Balance changed on the server; refresh the profile first")
    user.balance = new_balance
    await session.commit()
    return {"ok": True, "balance": user.balance}

@router.get("/profile")
async def profile(user: User = Depends(current_user)):
    return {
        "id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "avatar_url": f"/profile/avatar?v={user.id}",
        "photo_url": user.photo_url,
        "balance": user.balance,
        "stats": {"opened_cases": user.opened_cases, "wins": user.wins, "upgrades": user.upgrades},
    }


@router.get("/profile/avatar")
async def profile_avatar(
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    """Return the Telegram avatar through our API, so the Mini App does not
    depend on a client-side Telegram photo URL and the URL is not exposed."""
    tg_user = _parse_init_data(x_telegram_init_data or "")
    user_id = int(tg_user["id"])
    user = await session.get(User, user_id)
    photo_url = (user.photo_url if user else None) or tg_user.get("photo_url")

    async with httpx.AsyncClient(timeout=8.0, follow_redirects=True) as client:
        try:
            if not photo_url:
                api = f"https://api.telegram.org/bot{settings.bot_token.strip()}/getUserProfilePhotos"
                r = await client.get(api, params={"user_id": user_id, "limit": 1})
                r.raise_for_status()
                photos = r.json().get("result", {}).get("photos", [])
                if photos:
                    file_id = photos[0][-1]["file_id"]
                    fr = await client.get(
                        f"https://api.telegram.org/bot{settings.bot_token.strip()}/getFile",
                        params={"file_id": file_id},
                    )
                    fr.raise_for_status()
                    file_path = fr.json().get("result", {}).get("file_path")
                    if file_path:
                        photo_url = f"https://api.telegram.org/file/bot{settings.bot_token}/{file_path}"
                        if user:
                            user.photo_url = photo_url
                            await session.commit()
            if not photo_url:
                raise HTTPException(404, "Avatar not found")
            img = await client.get(photo_url)
            img.raise_for_status()
            content_type = img.headers.get("content-type", "image/jpeg").split(";", 1)[0]
            if not content_type.startswith("image/"):
                content_type = "image/jpeg"
            return Response(content=img.content, media_type=content_type, headers={"Cache-Control": "public, max-age=300"})
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(404, "Avatar not available") from exc


PROMO_REWARDS = {
    "LAIRJKS-123-512": 6000,
}

@router.post("/profile/promo")
async def redeem_promo(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    user_id = int(tg_user["id"])
    raw_code = str(payload.get("code") or "").strip().upper()
    if raw_code not in PROMO_REWARDS:
        raise HTTPException(400, "Неверный промокод")

    existing = await session.scalar(
        select(PromoRedemption).where(
            PromoRedemption.user_id == user_id,
            PromoRedemption.code == raw_code,
        )
    )
    if existing:
        raise HTTPException(400, "Этот промокод уже использован")

    user = await session.get(User, user_id)
    if not user:
        user = User(
            id=user_id,
            username=tg_user.get("username"),
            first_name=tg_user.get("first_name") or "Игрок",
            photo_url=tg_user.get("photo_url"),
            balance=0,
        )
        session.add(user)

    amount = PROMO_REWARDS[raw_code]
    user.username = tg_user.get("username")
    user.first_name = tg_user.get("first_name") or user.first_name
    user.photo_url = tg_user.get("photo_url") or user.photo_url
    user.balance = max(0, int(user.balance or 0)) + amount
    session.add(PromoRedemption(user_id=user_id, code=raw_code, amount=amount))
    await session.commit()
    return {"ok": True, "balance": user.balance, "amount": amount}
