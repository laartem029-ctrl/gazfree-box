import html
import logging
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from aiogram import Bot
from aiogram.enums import ParseMode

from database.database import get_session, settings
from database.models import User, Operation, Withdrawal
from api.routes.profile import _parse_init_data

router = APIRouter(tags=["withdrawals"])
ADMIN_USERNAME = "Ashleygi74"
logger = logging.getLogger("gazfree.withdrawals")

def _esc(value) -> str:
    return html.escape(str(value), quote=False)

def _norm_username(value: str | None) -> str:
    return str(value or "").strip().lstrip("@").lower()


@router.post("/withdrawals")
async def create_withdrawal(
    payload: dict,
    x_telegram_init_data: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    tg_user = _parse_init_data(x_telegram_init_data or "")
    telegram_user_id = int(tg_user["id"])
    user = await session.get(User, telegram_user_id)
    if not user:
        user = User(
            id=telegram_user_id,
            username=tg_user.get("username"),
            first_name=tg_user.get("first_name") or "Игрок",
            photo_url=tg_user.get("photo_url"),
            balance=0,
        )
        session.add(user)
        await session.flush()
    else:
        # Keep the verified Telegram identity authoritative.
        user.username = tg_user.get("username")
        user.first_name = tg_user.get("first_name") or user.first_name
        user.photo_url = tg_user.get("photo_url") or user.photo_url

    request_id = str(payload.get("request_id") or "").strip()
    if not request_id:
        request_id = str(uuid.uuid4())
    if len(request_id) > 100:
        raise HTTPException(400, "Invalid request id")

    # Idempotency: retrying the same withdrawal cannot send a second notification.
    existing = await session.scalar(select(Withdrawal).where(Withdrawal.request_id == request_id))
    if existing:
        return {"ok": True, "request_id": existing.request_id, "notified": bool(existing.notified), "duplicate": True}

    username = (user.username or payload.get("username") or "").strip().lstrip("@")
    first_name = user.first_name or str(payload.get("first_name") or "Игрок")
    gift_name = str(payload.get("gift_name") or "Подарок")[:255]
    gift_price = int(payload.get("gift_price") or 0)
    gift_case = str(payload.get("case") or "—")[:255]
    if gift_price < 0:
        raise HTTPException(400, "Invalid gift price")

    withdrawal = Withdrawal(
        request_id=request_id, user_id=user.id, username=username or None,
        first_name=first_name, gift_name=gift_name, gift_price=gift_price,
        gift_case=gift_case, status="pending", notified=False,
    )
    session.add(withdrawal)
    try:
        await session.flush()
    except IntegrityError:
        await session.rollback()
        existing = await session.scalar(select(Withdrawal).where(Withdrawal.request_id == request_id))
        if existing:
            return {"ok": True, "request_id": existing.request_id, "notified": bool(existing.notified), "duplicate": True}
        raise

    # Find the admin case-insensitively; Telegram usernames are not case-sensitive.
    admin = (await session.execute(
        select(User).where(func.lower(User.username) == _norm_username(ADMIN_USERNAME))
    )).scalars().first()

    notified = False
    if admin:
        who = f"@{_esc(username)}" if username else _esc(first_name)
        text = (
            "📤 <b>НОВЫЙ ВЫВОД</b>\n\n"
            f"👤 Пользователь: {who}\n"
            f"🆔 ID: <code>{user.id}</code>\n"
            f"🎁 Что выводит: {_esc(gift_name)}\n"
            f"💎 Сумма вывода: <b>{gift_price} ⭐</b>\n"
            f"📦 Кейс: {_esc(gift_case)}\n"
            f"🧾 Заявка: <code>{_esc(request_id)}</code>\n"
            f"🕒 Время: {datetime.utcnow().strftime('%d.%m.%Y %H:%M UTC')}"
        )
        bot = Bot(settings.bot_token)
        try:
            await bot.send_message(admin.id, text, parse_mode=ParseMode.HTML)
            notified = True
        except Exception:
            logger.exception("Failed to notify admin (id=%s) about withdrawal from user %s", admin.id, user.id)
        finally:
            await bot.session.close()
    else:
        logger.warning("Admin @%s is not present in DB; /start is required once.", ADMIN_USERNAME)

    withdrawal.notified = notified
    session.add(Operation(user_id=user.id, kind="withdrawal", amount=0, description=f"Вывод: {gift_name} ({gift_price} ⭐), request={request_id}"))
    await session.commit()
    return {"ok": True, "request_id": request_id, "notified": notified}


@router.post("/admin/give-stars")
async def admin_give_stars(
    payload: dict,
    x_admin_secret: str | None = Header(default=None),
    session: AsyncSession = Depends(get_session),
):
    configured_secret = getattr(settings, "admin_secret", "")
    # Keep the existing admin password working for this project while also
    # supporting a dedicated ADMIN_SECRET from .env.
    if not x_admin_secret or x_admin_secret not in {configured_secret, "lairjks-123-512"}:
        raise HTTPException(403, "Forbidden")
    username = _norm_username(payload.get("username"))
    amount = int(payload.get("amount") or 0)
    if not username or amount < 25 or amount > 6000 or amount % 25:
        raise HTTPException(400, "Invalid username or amount")

    # Case-insensitive lookup fixes @Username vs @username and accidental casing differences.
    user = (await session.execute(
        select(User).where(func.lower(User.username) == username)
    )).scalars().first()
    if not user:
        raise HTTPException(404, "User not found. The user must open the Mini App or start the bot first.")

    user.balance = int(user.balance or 0) + amount
    session.add(Operation(
        user_id=user.id, kind="admin_grant", amount=amount,
        description=f"Админ начислил {amount} ⭐ пользователю @{user.username or username}",
    ))
    await session.commit()
    return {"ok": True, "username": user.username or username, "balance": user.balance, "amount": amount}
