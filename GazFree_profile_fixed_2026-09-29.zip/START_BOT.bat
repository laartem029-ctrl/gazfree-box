@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  echo .env не найден. Запусти SETUP_ENV.bat.
  pause
  exit /b 1
)

set "PYTHON=%LocalAppData%\Programs\Python\Python314\python.exe"
if not exist "%PYTHON%" set "PYTHON=python"

"%PYTHON%" -m bot.main
if errorlevel 1 (
  echo.
  echo [ERROR] Бот остановился. Прочитай ошибку выше.
  pause
)
