import asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart
from aiogram.types import Message, WebAppInfo
from aiogram.utils.keyboard import InlineKeyboardBuilder
from database.database import settings, SessionLocal, init_db
from database.models import User

dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    async with SessionLocal() as session:
        user = await session.get(User, message.from_user.id)
        if not user:
            user = User(
                id=message.from_user.id,
                username=message.from_user.username,
                first_name=message.from_user.first_name or "Игрок",
                balance=0,
            )
            session.add(user)
        else:
            user.username = message.from_user.username
            user.first_name = message.from_user.first_name or user.first_name
        await session.commit()

    kb = InlineKeyboardBuilder()
    kb.button(
        text="🎮 Открыть GazFree",
        web_app=WebAppInfo(url=settings.webapp_url.strip())
    )
    await message.answer(
        f"Привет, {message.from_user.first_name}! 👋\n"
        "Открой Mini App, чтобы посмотреть профиль, игры и инвентарь.",
        reply_markup=kb.as_markup()
    )

async def main():
    # Бот может запускаться отдельно от FastAPI, поэтому БД
    # обязательно инициализируем перед обработкой /start.
    await init_db()
    bot = Bot(settings.bot_token)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
